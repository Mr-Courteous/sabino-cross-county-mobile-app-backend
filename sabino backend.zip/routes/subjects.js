const express = require('express');
const router = express.Router();
const pool = require('../database/db');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const authMiddleware = require('../middleware/auth');
require('dotenv').config();




router.use(authMiddleware.authenticateToken);

/**
 * @route   GET /api/subjects/search
 * @desc    Search the global subject library by keyword
 * @access  Private (Authenticated users only)
 */
router.get('/search', async (req, res) => {
  try {
    const { keyword } = req.query;

    let query = `
      SELECT id, subject_name as name, category, education_level 
      FROM global_subjects
    `;
    const params = [];

    if (keyword && keyword.trim()) {
      query += ` WHERE subject_name ILIKE $1`;
      params.push(`%${keyword.trim()}%`);
    }

    query += ` ORDER BY subject_name ASC LIMIT 50`;

    const result = await pool.query(query, params);

    res.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('❌ Subject Search Error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports=router;