const express = require('express');
const router = express.Router();
const pool = require('../database/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const authMiddleware = require('../middleware/auth');
const { validatePassword } = require('../utils/password-validator');
const rateLimit = require('express-rate-limit');
const axios = require('axios');

require('dotenv').config();

// ---------------------------------------------------------------------------
// Rate Limiters (Audit Recommendation #5)
// ---------------------------------------------------------------------------
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 OTP requests per window
  message: {
    success: false,
    error: 'Too many OTP requests. Please try again in 15 minutes.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Limit each IP to 10 login attempts per window
  message: {
    success: false,
    error: 'Too many login attempts. Please try again in 15 minutes.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// ---------------------------------------------------------------------------
// Subscription gating middleware
// Apply this AFTER authMiddleware.authenticateToken on any route that requires
// an active subscription (e.g. student lists, results, reports).
//
// Usage:
//   router.get('/students', authMiddleware.authenticateToken, checkSubscription, handler)
// ---------------------------------------------------------------------------
const checkSubscription = async (req, res, next) => {
  try {
    const schoolId = req.user?.id;
    if (!schoolId) {
      return res.status(401).json({ success: false, error: 'Authentication required.' });
    }

    const result = await pool.query(
      'SELECT payment_status, subscription_expiry FROM schools WHERE id = $1',
      [schoolId]
    );

    const school = result.rows[0];

    // If no school found, fail early
    if (!school) {
      return res.status(404).json({ success: false, error: 'School not found.' });
    }

    const { payment_status, subscription_expiry } = school;
    const now = new Date();

    // 1. Check if status is a paid status
    const paidStatuses = ['completed', 'grace_period'];
    if (!paidStatuses.includes(payment_status)) {
      return res.status(402).json({
        success: false,
        error: 'Subscription required.',
        message: 'Your school does not have an active subscription. Please subscribe via the Sabino app to access this feature.'
      });
    }

    // 2. Problem 4 Fix: Null expiry = data problem = block access
    if (!subscription_expiry) {
      console.warn(`🚨 [checkSubscription] Missing expiry for school ${schoolId} even though status is ${payment_status}`);
      return res.status(402).json({
        success: false,
        error: 'Subscription data incomplete.',
        message: 'Your subscription record is missing an expiry date. Please open the app and tap "Restore Purchases" to sync your account.'
      });
    }

    // 3. Check Expiry
    const expiryDate = new Date(subscription_expiry);
    if (expiryDate < now) {
      // Auto-fix status if EXPIRATION webhook was delayed
      await pool.query(
        "UPDATE schools SET payment_status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE id = $1 AND payment_status != 'expired'",
        [schoolId]
      );
      return res.status(402).json({
        success: false,
        error: 'Subscription expired.',
        message: 'Your subscription has expired. Please renew via the Sabino app to continue accessing premium features.'
      });
    }

    // 4. All good — attach info for potential frontend use
    req.subscription = {
      status: payment_status,
      expiresAt: expiryDate.toISOString(),
      daysRemaining: Math.ceil((expiryDate.getTime() - now.getTime()) / 86400000)
    };

    return next();

  } catch (error) {
    console.error('[checkSubscription] Error:', error);
    return res.status(500).json({ success: false, error: 'Failed to verify subscription status.' });
  }
};

// Email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_APP_PASSWORD,
  },
});
// Check account status WITHOUT sending OTP
router.get('/check-status/:email', async (req, res) => {
  try {
    const { email: rawEmail } = req.params;
    if (!rawEmail || rawEmail === 'undefined') return res.status(400).json({ error: "Email is required" });
    const email = rawEmail.toLowerCase();

    const result = await pool.query(
      'SELECT id, name, payment_status FROM schools WHERE email = $1',
      [email]
    );

    if (result.rows.length > 0) {
      const school = result.rows[0];
      return res.status(200).json({
        success: true,
        alreadyRegistered: true,
        resumePayment: school.payment_status === 'pending',
        data: {
          schoolId: school.id,
          name: school.name,
          paymentStatus: school.payment_status,
        }
      });
    }

    return res.status(200).json({
      success: true,
      alreadyRegistered: false
    });

  } catch (error) {
    console.error("Check Status Error:", error);
    res.status(500).json({ error: "Failed to check account status" });
  }
});


// Send OTP
router.post('/otp', otpLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });
    const normalizedEmail = email.trim().toLowerCase();

    // Check if school with this email already exists
    const existingSchool = await pool.query(
      'SELECT id, name, payment_status FROM schools WHERE email = $1',
      [normalizedEmail]
    );

    if (existingSchool.rows.length > 0) {
      const school = existingSchool.rows[0];
      return res.status(400).json({
        success: false,
        alreadyRegistered: true,
        resumePayment: school.payment_status === 'pending',
        message: school.payment_status === 'completed'
          ? 'This email is already registered. Please login instead.'
          : 'This email is already registered but payment is still pending. You can resume payment.',
        data: {
          schoolId: school.id,
          name: school.name,
          paymentStatus: school.payment_status,
        }
      });
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const otpHash = await bcrypt.hash(otp, 10);
    const expiresAt = new Date(Date.now() + 10 * 60000);

    await pool.query(
      `INSERT INTO email_verifications (email, otp_code, expires_at) 
       VALUES ($1, $2, $3) 
       ON CONFLICT (email) DO UPDATE 
       SET otp_code = $2, expires_at = $3, is_verified = false`,
      [email, otpHash, expiresAt]
    );

    const mailOptions = {
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Verify Your School Email",
      html: `
        <div style="font-family: sans-serif; text-align: center; border: 1px solid #ddd; padding: 20px;">
          <h2 style="color: #333;">Email Verification</h2>
          <p>Use the code below to complete your school registration:</p>
          <h1 style="color: #4A90E2; letter-spacing: 5px; font-size: 32px;">${otp}</h1>
          <p style="color: #888;">This code expires in 10 minutes.</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      alreadyRegistered: false,
      message: "Verification code sent successfully"
    });

  } catch (error) {
    console.error("Email/DB Error:", error);
    res.status(500).json({ error: "Failed to process request" });
  }

});

// Verify OTP
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: "Email and OTP are required"
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const verifyRes = await pool.query(
      'SELECT * FROM email_verifications WHERE email = $1 AND expires_at > NOW()',
      [normalizedEmail]
    );

    if (verifyRes.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired verification code"
      });
    }

    const isMatch = await bcrypt.compare(otp, verifyRes.rows[0].otp_code);
    if (!isMatch) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired verification code"
      });
    }

    await pool.query(
      'UPDATE email_verifications SET is_verified = true WHERE email = $1',
      [normalizedEmail]
    );

    return res.status(200).json({
      success: true,
      message: "OTP verified successfully."
    });

  } catch (error) {
    console.error("OTP Verification Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to verify OTP. Please try again later."
    });
  }
});

// Forgot Password - Send OTP
router.post('/forgot-password', otpLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const normalizedEmail = email.trim().toLowerCase();
    // Check if school with this email exists
    const existingSchool = await pool.query(
      'SELECT id, name FROM schools WHERE email = $1',
      [normalizedEmail]
    );

    if (existingSchool.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: "No school account found with this email address.",
        message: "Account not found"
      });
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const otpHash = await bcrypt.hash(otp, 10);
    const expiresAt = new Date(Date.now() + 10 * 60000);

    await pool.query(
      `INSERT INTO email_verifications (email, otp_code, expires_at) 
       VALUES ($1, $2, $3) 
       ON CONFLICT (email) DO UPDATE 
       SET otp_code = $2, expires_at = $3, is_verified = false`,
      [email, otpHash, expiresAt]
    );

    const mailOptions = {
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "School Account Password Reset",
      html: `
        <div style="font-family: sans-serif; text-align: center; border: 1px solid #ddd; padding: 20px;">
          <h2 style="color: #333;">Password Reset</h2>
          <p>Use the code below to reset your school administrator password:</p>
          <h1 style="color: #4A90E2; letter-spacing: 5px; font-size: 32px;">${otp}</h1>
          <p style="color: #888;">This code expires in 10 minutes. If you didn't request this, please ignore this email.</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      message: "Reset code sent successfully"
    });

  } catch (error) {
    console.error("Forgot Password Error:", error);
    res.status(500).json({ error: "Failed to process request" });
  }
});

// Reset Password
router.post('/reset-password', async (req, res) => {
  const client = await pool.connect();
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and new password are required"
      });
    }

    // Verify email is verified in email_verifications table
    const verificationCheck = await client.query(
      'SELECT is_verified FROM email_verifications WHERE email = $1 AND is_verified = true',
      [email]
    );

    if (verificationCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Email must be verified first. Please complete OTP verification.'
      });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        success: false,
        error: passwordValidation.error
      });
    }

    await client.query('BEGIN');

    // Hash password
    const normalizedEmail = email.trim().toLowerCase();
    const hashedPassword = await bcrypt.hash(password, 10);

    // Update school password
    const updateResult = await client.query(
      'UPDATE schools SET password = $1, updated_at = CURRENT_TIMESTAMP WHERE email = $2 RETURNING id',
      [hashedPassword, normalizedEmail]
    );

    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'School not found'
      });
    }

    // Clean up verification record
    await client.query('DELETE FROM email_verifications WHERE email = $1', [email]);

    await client.query('COMMIT');

    res.status(200).json({
      success: true,
      message: 'Password reset successful. You can now login with your new password.'
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Reset Password Error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  } finally {
    client.release();
  }
});

// Create school (or resume pending registration)
router.post('/', async (req, res) => {
  try {
    const { name, email, password, school_type, country_id, country, phone } = req.body;

    if (!name || !email || !password || !school_type || (!country_id && !country)) {
      return res.status(400).json({ success: false, message: 'All required fields must be filled, including country' });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        success: false,
        message: passwordValidation.error
      });
    }

    const emailVerified = await pool.query(
      'SELECT is_verified FROM email_verifications WHERE email = $1 AND is_verified = true',
      [email]
    );

    if (emailVerified.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Email must be verified first. Please complete OTP verification.'
      });
    }

    // Check for existing school record by email
    const existingSchoolRes = await pool.query(
      'SELECT id, name, email, phone, school_type, country_id, country, payment_status FROM schools WHERE email = $1',
      [email]
    );

    if (existingSchoolRes.rows.length > 0) {
      const existingSchool = existingSchoolRes.rows[0];

      if (existingSchool.payment_status === 'completed') {
        return res.status(400).json({
          success: false,
          message: 'This email is already registered and active.'
        });
      }

      // Pending payment - return user data and a fresh JWT allowing them to resume payment
      const resumeToken = jwt.sign(
        {
          id: existingSchool.id,
          schoolId: existingSchool.id,
          type: 'school',
          email: existingSchool.email,
          name: existingSchool.name,
          countryId: existingSchool.country_id
        },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
      );

      return res.status(200).json({
        success: true,
        resumePayment: true,
        data: {
          token: resumeToken,
          user: {
            schoolId: existingSchool.id,
            email: existingSchool.email,
            name: existingSchool.name,
            type: 'school',
            countryId: existingSchool.country_id,
            country: existingSchool.country,
            phone: existingSchool.phone,
            paymentStatus: existingSchool.payment_status
          }
        }
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    // New registration path
    const hashedPassword = await bcrypt.hash(password, 10);
    const registrationCode = crypto.randomBytes(4).toString('hex').toUpperCase();

    const result = await pool.query(
      `INSERT INTO schools (
        registration_code, name, email, password, school_type,
        country_id, country, phone, payment_status
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id, name, email, country_id`,
      [
        registrationCode,
        name,
        normalizedEmail,
        hashedPassword,
        school_type,
        country_id || null,
        country || null,
        phone || null,
        'pending'
      ]
    );

    const school = result.rows[0];

    // Auto-create default academic session for immediate use
    const currentYear = new Date().getFullYear();
    const defaultSessionName = `${currentYear}/${currentYear + 1}`;

    try {
      await pool.query(
        `INSERT INTO academic_sessions (school_id, session_name, is_active)
         VALUES ($1, $2, $3)
         ON CONFLICT (school_id, session_name) DO UPDATE
         SET is_active = $3`,
        [school.id, defaultSessionName, true]
      );
      console.log(`✓ Default academic session created for school: ${defaultSessionName}`);
    } catch (sessionError) {
      console.error('Warning: Failed to create default academic session:', sessionError);
      // Don't fail registration if session creation fails
    }

    // If country_id was not provided, attempt to resolve it using the country name
    let resolvedCountryId = country_id;
    if (!resolvedCountryId && country) {
      try {
        const countryRow = await pool.query(
          'SELECT id FROM countries WHERE name = $1 LIMIT 1',
          [country]
        );
        if (countryRow.rows.length > 0) {
          resolvedCountryId = countryRow.rows[0].id;
        }
      } catch (countryLookupError) {
        console.warn('Warning: Failed to lookup country:', countryLookupError);
      }
    }

    // Create default preference row for the school (if table exists)
    try {
      await pool.query('INSERT INTO school_preferences (school_id) VALUES ($1)', [school.id]);
    } catch (prefError) {
      console.warn('Warning: Failed to create default school preferences:', prefError);
    }

    const token = jwt.sign(
      {
        id: school.id,
        schoolId: school.id,
        type: 'school',
        email: school.email,
        name,
        countryId: resolvedCountryId
      },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    return res.status(201).json({
      success: true,
      data: {
        token,
        user: {
          schoolId: school.id,
          email: school.email,
          name,
          type: 'school',
          countryId: resolvedCountryId,
          paymentStatus: 'pending'
        }
      }
    });
  } catch (error) {
    console.error('Registration Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Registration failed. Please try again later.',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// POST /api/schools/revenuecat-webhook
// RevenueCat sends this request server-to-server on every subscription event.
// Security: RevenueCat sends Authorization as "Bearer <token>" — must strip the prefix before comparing.
// Configure REVENUECAT_WEBHOOK_AUTH_TOKEN in .env and the same value in RevenueCat Dashboard → Webhooks.
router.post('/revenuecat-webhook', async (req, res) => {
  try {
    // 1. Security Check: Extract token from "Bearer <token>" format
    const authHeader = req.headers.authorization;
    const token = authHeader?.replace('Bearer ', '');

    if (!token || token !== process.env.REVENUECAT_WEBHOOK_AUTH_TOKEN) {
      console.log("❌ Unauthorized webhook attempt. Header:", authHeader);
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const { event } = req.body;


    if (!event) {
      console.warn('[RC Webhook] No event object in payload');
      return res.status(200).send('Webhook received');
    }

    const { type, app_user_id, expiration_at_ms, id: event_id } = event;

    if (!app_user_id) {
      console.warn('[RC Webhook] No app_user_id in payload. Event type:', type);
      return res.status(200).send('Webhook received');
    }

    // 1.5 Idempotency Check (Problem 2 Fix: Use event_id column, not SERIAL id)
    const existingEvent = await pool.query('SELECT id FROM webhook_events WHERE event_id = $1', [event_id]);
    if (existingEvent.rows.length > 0) {
      console.log(`[RC Webhook] Event ${event_id} already processed. Skipping.`);
      return res.status(200).send('Webhook received');
    }

    // 1.8 School Existence Check (Problem 3 Fix)
    const schoolCheck = await pool.query(
      'SELECT id, name, email FROM schools WHERE id = $1',
      [app_user_id]
    );

    if (schoolCheck.rows.length === 0) {
      console.error(`❌ [RC Webhook] CRITICAL: School ID "${app_user_id}" not found in DB.`);
      console.error(`This likely means the Android app is NOT calling Purchases.logIn(schoolId) before purchase.`);
      // Still return 200 to stop retries, but log it clearly
      return res.status(200).send('School not found');
    }

    const school = schoolCheck.rows[0];

    console.log(`[RC Webhook] Event: ${type} for School ID: ${app_user_id} (ID: ${event_id})`);

    // 2. Handle relevant events
    if (type === 'INITIAL_PURCHASE' || type === 'RENEWAL' || type === 'NON_RENEWING_PURCHASE') {
      // Problem 2 Fix: Never trust null expiry for non-renewing purchases. 
      // Default to 4 months if expiration_at_ms is missing.
      let exactExpiry;
      if (expiration_at_ms) {
        exactExpiry = new Date(expiration_at_ms).toISOString();
      } else {
        const fourMonthsLater = new Date();
        fourMonthsLater.setMonth(fourMonthsLater.getMonth() + 4);
        exactExpiry = fourMonthsLater.toISOString();
        console.log(`🕒 [RC Webhook] No expiry in payload. Defaulting to 4 months: ${exactExpiry}`);
      }

      await pool.query(
        'UPDATE schools SET payment_status = $1, subscription_expiry = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        ['completed', exactExpiry, app_user_id]
      );

      console.log(`✅ [RC Webhook] ${type}: School ${app_user_id} activated until ${exactExpiry}`);
    }
    else if (type === 'EXPIRATION') {
      // Move to 'expired' status
      await pool.query(
        'UPDATE schools SET payment_status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['expired', app_user_id]
      );

      // Notify school about expiration
      try {
        if (school.email) {
          await transporter.sendMail({
            from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
            to: school.email,
            subject: 'Your Sabino Edu Subscription has Expired',
            html: `
              <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
                <h2 style="color: #2563EB;">Access Suspended</h2>
                <p>Hello <strong>${school.name}</strong>,</p>
                <p>Your premium subscription to Sabino Edu has expired. Your portal access and results generation have been temporarily suspended.</p>
                <div style="background: #F1F5F9; padding: 15px; border-radius: 8px; margin: 20px 0;">
                  <p style="margin: 0;"><strong>Action Required:</strong> Log in to your dashboard to renew your access and continue managing your students.</p>
                </div>
                <p>If you have already renewed, please ignore this message or tap "Restore Purchases" in the app.</p>
                <p>Best regards,<br/>Sabino Edu Team</p>
              </div>
            `
          });
          console.log(`📧 [RC Webhook] Expiration email sent to ${school.email}`);
        }
      } catch (emailErr) {
        console.error('❌ [RC Webhook] Failed to send expiration email:', emailErr);
      }

      console.log(`⚠️ [RC Webhook] EXPIRATION: School ID ${app_user_id} moved to expired status`);
    }
    else if (type === 'GRACE_PERIOD_STARTED') {
      // Allow access during grace period
      await pool.query(
        'UPDATE schools SET payment_status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['grace_period', app_user_id]
      );
      console.log(`🕒 [RC Webhook] GRACE_PERIOD: School ID ${app_user_id} entered grace period`);
    }
    else if (type === 'CANCELLATION' || type === 'BILLING_ISSUE') {
      console.log(`ℹ️ [RC Webhook] ${type}: Event received for School ID ${app_user_id}`);
    }
    else {
      console.log(`[RC Webhook] Unhandled event type "${type}". Ignoring.`);
    }

    // 2.5 Record processed event for idempotency (Problem 2 Fix: Use event_id column)
    await pool.query(
      'INSERT INTO webhook_events (event_id, type, app_user_id, payload) VALUES ($1, $2, $3, $4)',
      [event_id, type, app_user_id, JSON.stringify(req.body)]
    );

    // 3. Always respond with 200 OK
    res.status(200).send('Webhook received');

  } catch (error) {
    console.error('❌ [RC Webhook] Error:', error);
    // Still return 200 so RevenueCat doesn't retry indefinitely
    res.status(200).send('Webhook received');
  }
});

/**
 * @route   POST /api/schools/sync-subscription
 * @desc    Manual sync with RevenueCat API to ensure local DB matches RC status.
 *
 *          ROOT CAUSE FIX (payment succeeds but school never gets marked
 *          'completed'): RevenueCat's REST API is eventually consistent —
 *          right after a purchase, the SDK on-device already knows the
 *          purchase succeeded, but RC's subscriber endpoint can take a
 *          few seconds to reflect it (this is worse for a subscriber's
 *          very first purchase). The client calls this route immediately
 *          after `Purchases.purchasePackage()` resolves, so a single,
 *          immediate GET to /v1/subscribers/{id} can legitimately come
 *          back with no active entitlement yet — even though the money
 *          was already taken. That left payment_status stuck on
 *          'pending', which is what sent the school back to the pricing
 *          screen on every subsequent request (see the 402 interceptor
 *          in app/_layout.tsx on the client).
 *
 *          Fix: retry the RC lookup a few times with a short backoff
 *          before concluding there's no active entitlement. The
 *          RevenueCat webhook (below) remains the authoritative,
 *          eventually-consistent source of truth regardless.
 * @access  Private (School Admin)
 */
const RC_SYNC_MAX_ATTEMPTS = 4;
const RC_SYNC_RETRY_DELAY_MS = 2000;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

router.post('/sync-subscription', authMiddleware.authenticateToken, authMiddleware.requireSchool, async (req, res) => {
  try {
    const schoolId = req.user.schoolId || req.user.id;
    const RC_API_KEY = process.env.REVENUECAT_REST_API_KEY;

    if (!RC_API_KEY) {
      console.warn('⚠️ REVENUECAT_REST_API_KEY not configured. Skipping manual sync.');
      return res.status(503).json({ success: false, message: 'Sync service unavailable' });
    }

    const entitlementId = process.env.REVENUECAT_ENTITLEMENT_ID || 'premium';
    let entitlement = null;
    let lastSubscriber = null;
    let lastFetchFailed = false;

    for (let attempt = 1; attempt <= RC_SYNC_MAX_ATTEMPTS; attempt++) {
      console.log(`🔄 [RC Sync] Fetching status for School ID: ${schoolId} (attempt ${attempt}/${RC_SYNC_MAX_ATTEMPTS})`);

      let subscriber;
      try {
        const response = await axios.get(
          `https://api.revenuecat.com/v1/subscribers/${schoolId}`,
          {
            headers: {
              'Authorization': `Bearer ${RC_API_KEY}`,
              'Content-Type': 'application/json'
            }
          }
        );
        subscriber = response.data.subscriber;
        lastFetchFailed = false;
      } catch (rcErr) {
        console.error(`❌ [RC Sync] RevenueCat API error on attempt ${attempt}:`, rcErr.response?.data || rcErr.message);
        subscriber = null;
        lastFetchFailed = true;
      }

      lastSubscriber = subscriber;
      const entitlements = subscriber?.entitlements || {};
      entitlement = entitlements[entitlementId] || Object.values(entitlements)[0] || null;

      if (entitlement) break; // found it — no need to keep retrying

      if (attempt < RC_SYNC_MAX_ATTEMPTS) {
        await sleep(RC_SYNC_RETRY_DELAY_MS);
      }
    }

    if (!entitlement) {
      // Diagnostic dump — this tells us WHY, instead of just THAT it failed.
      if (lastFetchFailed) {
        console.warn(`⚠️ [RC Sync] Diagnosis: the RevenueCat API call itself kept failing (see the ❌ lines above — likely a bad/expired REVENUECAT_REST_API_KEY, or a network/DNS issue reaching api.revenuecat.com).`);
      } else if (!lastSubscriber) {
        console.warn(`⚠️ [RC Sync] Diagnosis: RevenueCat returned no subscriber object at all for schoolId "${schoolId}". Unexpected — RC normally auto-creates an empty subscriber record even for an unknown id.`);
      } else {
        const entitlementKeys = Object.keys(lastSubscriber.entitlements || {});
        const subscriptionKeys = Object.keys(lastSubscriber.subscriptions || {});
        console.warn(`⚠️ [RC Sync] Diagnosis for schoolId "${schoolId}":`);
        console.warn(`   RC's own id for this customer (original_app_user_id): ${lastSubscriber.original_app_user_id}`);
        console.warn(`   Entitlements RC has on file: [${entitlementKeys.join(', ') || 'none'}] (looking for "${entitlementId}")`);
        console.warn(`   Raw subscriptions RC has on file: [${subscriptionKeys.join(', ') || 'none'}]`);
        if (subscriptionKeys.length > 0 && entitlementKeys.length === 0) {
          console.warn(`   👉 A subscription IS on file but is not attached to ANY entitlement. This usually means the product isn't linked to an entitlement in the RevenueCat dashboard (Products/Entitlements setup) — not a timing issue, and retrying will never fix it.`);
        } else if (subscriptionKeys.length === 0 && entitlementKeys.length === 0) {
          console.warn(`   👉 RevenueCat has NOTHING on file for schoolId "${schoolId}" — no subscriptions, no entitlements. This means the purchase was almost certainly recorded under a DIFFERENT app_user_id (the app didn't call Purchases.logIn(schoolId) before the purchase, or it ran after). Check Purchases.getAppUserID() on-device right before purchasePackage() and compare it to this schoolId.`);
        }
      }
    }

    if (entitlement) {
      const expiry = entitlement.expires_date;
      // A null expires_date means a non-expiring (lifetime / non-renewing
      // with no configured duration) entitlement — that's active, not
      // expired. Only compare dates when RC actually gave us one.
      const isActive = !expiry || new Date(expiry) > new Date();

      await pool.query(
        'UPDATE schools SET payment_status = $1, subscription_expiry = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        [isActive ? 'completed' : 'expired', expiry || null, schoolId]
      );

      console.log(`✅ [RC Sync] School ${schoolId} synced: ${isActive ? 'active' : 'expired'} (expiry: ${expiry || 'none'})`);

      return res.json({
        success: true,
        message: 'Subscription status synced successfully',
        data: { isActive, expiry: expiry || null }
      });
    }

    console.warn(`⚠️ [RC Sync] No entitlement found for School ${schoolId} after ${RC_SYNC_MAX_ATTEMPTS} attempts.`);
    return res.json({
      success: true,
      message: 'No active entitlements found yet. If you just paid, this can take a moment to confirm — try again shortly.',
      data: { isActive: false }
    });

  } catch (error) {
    console.error('❌ [RC Sync] Error:', error.response?.data || error.message);
    res.status(500).json({ success: false, message: 'Failed to sync with RevenueCat' });
  }
});

// End of Subscription Routes


// Get user schools (requires auth)
router.get('/', authMiddleware.authenticateToken, authMiddleware.requireSchool, async (req, res) => {
  try {
    // STRICT SECURITY: Extract userId ONLY from token, never from req.body or req.query
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    const result = await pool.query(
      'SELECT * FROM schools WHERE owner_id = $1 ORDER BY created_at DESC',
      [userId]
    );

    res.json({
      schools: result.rows,
      count: result.rows.length,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get current school details using token
router.get('/me', authMiddleware.authenticateToken, checkSubscription, authMiddleware.requireSchool, async (req, res) => {
  try {
    // STRICT SECURITY: Extract schoolId ONLY from token, never from req.body or req.query
    // The authenticateToken middleware attaches the decoded token to req.user
    // In your generateToken function, you stored schoolId as 'id'
    const schoolId = req.user?.id;

    if (!schoolId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    const result = await pool.query(
      `SELECT 
        s.id, 
        s.registration_code, 
        s.name, 
        s.address,
        s.city,
        s.state,
        s.country, 
        s.phone, 
        s.email, 
        s.school_type, 
        COALESCE(pref.logo_url, s.logo) AS logo,
        COALESCE(pref.stamp_url, s.stamp) AS stamp,
        s.created_at
      FROM schools s
      LEFT JOIN school_preferences pref ON pref.school_id = s.id
      WHERE s.id = $1`,
      [schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'School record not found'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Fetch school profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error retrieving profile'
    });
  }
});

// Update current school details using token
router.put('/me', authMiddleware.authenticateToken, authMiddleware.requireSchool, authMiddleware.requireOwner, async (req, res) => {
  try {
    const schoolId = req.user?.id;
    if (!schoolId) {
      return res.status(401).json({ success: false, error: 'Authentication missing' });
    }

    const { name, address, city, state, phone, email, registration_code } = req.body;

    const result = await pool.query(
      `UPDATE schools SET 
       name = COALESCE($1, name), 
       address = COALESCE($2, address), 
       city = COALESCE($3, city), 
       state = COALESCE($4, state), 
       phone = COALESCE($5, phone), 
       email = COALESCE($6, email), 
       registration_code = COALESCE($7, registration_code), 
       updated_at = CURRENT_TIMESTAMP 
       WHERE id = $8 
       RETURNING *`,
      [name, address, city, state, phone, email, registration_code, schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'School not found' });
    }

    res.json({
      success: true,
      message: 'School profile updated successfully',
      data: result.rows[0],
    });
  } catch (error) {
    console.error('Update school profile error:', error);
    res.status(500).json({ success: false, error: 'Server error updating profile' });
  }
});

// Update school (requires auth)
router.put('/:schoolId', authMiddleware.authenticateToken, authMiddleware.requireSchool, authMiddleware.checkSchoolOwnership, authMiddleware.requireOwner, async (req, res) => {
  try {
    const { schoolId } = req.params;
    const { name, address, city, state, country, phone, email, registration_code } = req.body;

    const result = await pool.query(
      `UPDATE schools SET 
       name = COALESCE($1, name), 
       address = COALESCE($2, address), 
       city = COALESCE($3, city), 
       state = COALESCE($4, state), 
       country = COALESCE($5, country), 
       phone = COALESCE($6, phone), 
       email = COALESCE($7, email), 
       registration_code = COALESCE($8, registration_code), 
       updated_at = CURRENT_TIMESTAMP 
       WHERE id = $9 
       RETURNING *`,
      [name, address, city, state, country, phone, email, registration_code, schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'School not found' });
    }

    res.json({
      message: 'School updated successfully',
      school: result.rows[0],
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * @route   DELETE /api/schools/delete-account
 * @desc    Permanently delete a school account via email + password (web form flow)
 * @access  Public — no token required, identity verified via email + password
 */
router.delete('/delete-account', async (req, res) => {
  const client = await pool.connect();

  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required.'
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const schoolResult = await pool.query(
      'SELECT id, email, name, password FROM schools WHERE LOWER(email) = $1',
      [normalizedEmail]
    );

    // console.log('Lookup result for', normalizedEmail, '→', schoolResult.rows.length, 'rows found');

    if (schoolResult.rows.length === 0) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const school = schoolResult.rows[0];
    const passwordMatch = await bcrypt.compare(password, school.password);

    if (!passwordMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const schoolId = school.id;

    await client.query('BEGIN');

    // 1. Scores reference enrollments (not students directly)
    await client.query('DELETE FROM scores WHERE school_id = $1', [schoolId]);

    // 2. Enrollments reference students, classes, academic_sessions
    await client.query('DELETE FROM enrollments WHERE school_id = $1', [schoolId]);

    // 3. Students, sessions, classes, subjects
    await client.query('DELETE FROM students WHERE school_id = $1', [schoolId]);
    await client.query('DELETE FROM academic_sessions WHERE school_id = $1', [schoolId]);
    await client.query('DELETE FROM classes WHERE school_id = $1', [schoolId]);
    await client.query('DELETE FROM subjects WHERE school_id = $1', [schoolId]);

    // 4. Payment & subscription data
    await client.query('DELETE FROM payment_transactions WHERE school_id = $1', [schoolId]);
    await client.query('DELETE FROM school_subscriptions WHERE school_id = $1', [schoolId]);

    // 5. Preferences & devices
    await client.query('DELETE FROM school_preferences WHERE school_id = $1', [schoolId]);
    await client.query('DELETE FROM device_tokens WHERE school_id = $1', [schoolId]);

    // 6. Finally the school itself
    await client.query('DELETE FROM schools WHERE id = $1', [schoolId]);

    await client.query('COMMIT');

    transporter.sendMail({
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: school.email,
      subject: 'Your Sabino Edu account has been deleted',
      html: `
        <div style="font-family: sans-serif; padding: 24px; border: 1px solid #eee; max-width: 500px; margin: auto;">
          <h2 style="color: #d32f2f;">Account Deleted</h2>
          <p>Hi <strong>${school.name}</strong>,</p>
          <p>Your Sabino Edu account and all associated data (students, classes, grades, preferences)
          have been permanently deleted as requested.</p>
          <p>If you did not request this, please contact us immediately at
          <a href="mailto:${process.env.EMAIL_USER}">${process.env.EMAIL_USER}</a>.</p>
          <p style="color: #aaa; font-size: 12px;">This action is irreversible.</p>
        </div>
      `
    }).catch(err => console.error('❌ Deletion confirmation email failed:', err.message));

    console.log(`🗑️ Account permanently deleted: School ${schoolId} (${school.email})`);

    res.json({
      success: true,
      message: 'Your account and all associated data have been permanently deleted.'
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Account deletion error:', error.message);
    res.status(500).json({
      success: false,
      error: 'Failed to delete account. Please try again or contact support.'
    });
  } finally {
    client.release();
  }
});

// Delete school (requires auth)
router.delete('/:schoolId', authMiddleware.authenticateToken, authMiddleware.requireSchool, authMiddleware.checkSchoolOwnership, authMiddleware.requireOwner, async (req, res) => {
  try {
    const { schoolId } = req.params;

    const result = await pool.query(
      'DELETE FROM schools WHERE id = $1 RETURNING id',
      [schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'School not found' });
    }

    res.json({ message: 'School deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Called after login — doesn't create a new row, just links school identity
router.post('/push-token', authMiddleware.authenticateToken, async (req, res) => {
  const { token, appVersion } = req.body;
  const schoolId = req.user.schoolId || req.user.id;

  if (!token || !token.startsWith('ExponentPushToken[')) {
    return res.status(400).json({ success: false, error: 'Invalid push token' });
  }

  try {
    await pool.query(
      `INSERT INTO device_tokens (expo_token, app_version, school_id, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (expo_token) DO UPDATE SET
         school_id = EXCLUDED.school_id,
         app_version = EXCLUDED.app_version,
         updated_at = NOW()`,
      [token, appVersion || null, schoolId]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
