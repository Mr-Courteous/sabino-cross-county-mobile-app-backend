const express = require('express');
const router = express.Router({ mergeParams: true });
const pool = require('../database/db');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const authMiddleware = require('../middleware/auth');
const checkSubscription = require('../middleware/checkSubscription');
const { auditRoute } = require('../middleware/auditLog');
const { validatePassword } = require('../utils/password-validator');
const multer = require('multer');
const { put } = require('@vercel/blob');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

// ---------------------------------------------------------
// Rate Limiters (Audit Recommendation #5)
// ---------------------------------------------------------
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 OTP requests per window
  message: { 
    success: false, 
    error: 'Too many OTP requests. Please try again in 15 minutes.' 
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Limit each IP to 10 login attempts per window
  message: { 
    success: false, 
    error: 'Too many login attempts. Please try again in 15 minutes.' 
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Configure multer for memory storage
const upload = multer({ storage: multer.memoryStorage() });

// Email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_APP_PASSWORD,
  },
});

// NOTE: Auth middleware is applied selectively per route
// Student registration and login are public routes

/**
 * =====================================================================
 * STUDENTS & ENROLLMENTS MANAGEMENT
 * =====================================================================
 * 
 * Architecture:
 * - Students are independent entities tied to schools (not to classes)
 * - Enrollments link students to classes for specific academic sessions
 * - Supports promotions, repeaters, and student transfers between classes
 * - Full historical tracking for transcripts and enrollment history
 * - Enrollment status: 'active', 'promoted', 'repeated', 'transferred', 'graduated'
 */

// =====================================================================
// STUDENT SELF-SERVICE ENDPOINTS (PUBLIC & AUTHENTICATED)
// =====================================================================

// Send OTP
router.post('/otp', otpLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const normalizedEmail = email.trim().toLowerCase();
    
    // Check if student with this email already exists
    const existingStudent = await pool.query(
      'SELECT id, first_name, last_name FROM students WHERE email = $1',
      [normalizedEmail]
    );

    if (existingStudent.rows.length > 0) {
      return res.status(409).json({
        success: false,
        error: "A student with this email is already registered. Please login instead.",
        message: "This email is already registered"
      });
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const otpHash = await bcrypt.hash(otp, 10);
    const expiresAt = new Date(Date.now() + 10 * 60000);

    await pool.query(
      `INSERT INTO email_verifications (email, otp_code, expires_at) 
       VALUES ($1, $2, $3) 
       ON CONFLICT (email) DO UPDATE 
       SET otp_code = $2, expires_at = $3, is_verified = false`,
      [normalizedEmail, otpHash, expiresAt]
    );

    const mailOptions = {
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: normalizedEmail,
      subject: "Verify Your Student Email",
      html: `
        <div style="font-family: sans-serif; text-align: center; border: 1px solid #ddd; padding: 20px;">
          <h2 style="color: #333;">Email Verification</h2>
          <p>Use the code below to complete your student registration:</p>
          <h1 style="color: #4A90E2; letter-spacing: 5px; font-size: 32px;">${otp}</h1>
          <p style="color: #888;">This code expires in 10 minutes.</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      message: "Verification code sent successfully"
    });

  } catch (error) {
    console.error("Email/DB Error:", error.message);
    res.status(500).json({ error: "Failed to process request" });
  }
});

// Verify OTP
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: "Email and OTP are required"
      });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const verifyRes = await pool.query(
      'SELECT * FROM email_verifications WHERE email = $1 AND expires_at > NOW()',
      [normalizedEmail]
    );

    if (verifyRes.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired verification code"
      });
    }

    const isMatch = await bcrypt.compare(otp, verifyRes.rows[0].otp_code);
    if (!isMatch) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired verification code"
      });
    }

    await pool.query(
      'UPDATE email_verifications SET is_verified = true WHERE email = $1',
      [normalizedEmail]
    );

    return res.status(200).json({
      success: true,
      message: "OTP verified successfully."
    });

  } catch (error) {
    console.error("OTP Verification Error:", error.message);
    return res.status(500).json({
      success: false,
      message: "Failed to verify OTP. Please try again later."
    });
  }
});

// Forgot Password - Send OTP
router.post('/forgot-password', otpLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const normalizedEmail = email.trim().toLowerCase();
    
    // Check if student with this email exists
    const existingStudent = await pool.query(
      'SELECT id, first_name FROM students WHERE email = $1',
      [normalizedEmail]
    );

    if (existingStudent.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: "No student account found with this email address.",
        message: "Account not found"
      });
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const otpHash = await bcrypt.hash(otp, 10);
    const expiresAt = new Date(Date.now() + 10 * 60000);

    await pool.query(
      `INSERT INTO email_verifications (email, otp_code, expires_at) 
       VALUES ($1, $2, $3) 
       ON CONFLICT (email) DO UPDATE 
       SET otp_code = $2, expires_at = $3, is_verified = false`,
      [normalizedEmail, otpHash, expiresAt]
    );

    const mailOptions = {
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: normalizedEmail,
      subject: "Password Reset Code",
      html: `
        <div style="font-family: sans-serif; text-align: center; border: 1px solid #ddd; padding: 20px;">
          <h2 style="color: #333;">Password Reset</h2>
          <p>Use the code below to reset your student portal password:</p>
          <h1 style="color: #4A90E2; letter-spacing: 5px; font-size: 32px;">${otp}</h1>
          <p style="color: #888;">This code expires in 10 minutes. If you didn't request this, please ignore this email.</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      message: "Reset code sent successfully"
    });

  } catch (error) {
    console.error("Forgot Password Error:", error.message);
    res.status(500).json({ error: "Failed to process request" });
  }
});

// Reset Password
router.post('/reset-password', async (req, res) => {
  const client = await pool.connect();
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and new password are required"
      });
    }

    // Verify email is verified in email_verifications table
    const verificationCheck = await client.query(
      'SELECT is_verified FROM email_verifications WHERE email = $1 AND is_verified = true',
      [email]
    );

    if (verificationCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Email must be verified first. Please complete OTP verification.'
      });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        success: false,
        error: passwordValidation.error
      });
    }

    await client.query('BEGIN');

    // Hash password
    const normalizedEmail = email.trim().toLowerCase();
    const passwordHash = await bcrypt.hash(password, 10);

    // Update student password
    const updateResult = await client.query(
      'UPDATE students SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE email = $2 RETURNING id',
      [passwordHash, normalizedEmail]
    );

    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'Student not found'
      });
    }

    // Clean up verification record
    await client.query('DELETE FROM email_verifications WHERE email = $1', [normalizedEmail]);

    await client.query('COMMIT');

    res.status(200).json({
      success: true,
      message: 'Password reset successful. You can now login with your new password.'
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Reset Password Error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  } finally {
    client.release();
  }
});

/**
 * @route   POST /api/students/register
 * @desc    Student self-registration (creates account with password)
 * @access  Public
 * @body    {
 *            firstName: String (required),
 *            lastName: String (required),
 *            email: String (required),
 *            password: String (required),
 *            registrationNumber: String (optional),
 *            phone: String (optional),
 *            dateOfBirth: String (optional, YYYY-MM-DD),
 *            gender: String (optional),
 *            schoolId: Number (required)
 *          }
 */
router.post('/register', async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      firstName, lastName, email, password,
      registrationNumber, phone, dateOfBirth, gender, registrationCode, address
    } = req.body;

    // Validation
    const requiredFields = ['firstName', 'lastName', 'email', 'password', 'registrationCode'];
    for (const field of requiredFields) {
      if (!req.body[field]) {
        return res.status(400).json({
          success: false,
          error: `${field} is required`,
          missingField: field
        });
      }
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Verify school exists by registration_code
    const schoolCheck = await client.query(
      'SELECT id, name FROM schools WHERE registration_code = $1',
      [registrationCode]
    );

    if (schoolCheck.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Invalid Registration Code. School not found.'
      });
    }

    const schoolId = schoolCheck.rows[0].id;
    const schoolName = schoolCheck.rows[0].name;

    // Check if email already exists
    const emailCheck = await client.query(
      'SELECT id FROM students WHERE email = $1',
      [normalizedEmail]
    );

    if (emailCheck.rows.length > 0) {
      return res.status(409).json({
        success: false,
        error: 'Email already registered'
      });
    }

    // Verify email is verified in email_verifications table
    const verificationCheck = await client.query(
      'SELECT is_verified FROM email_verifications WHERE email = $1 AND is_verified = true',
      [normalizedEmail]
    );

    if (verificationCheck.rows.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Email must be verified first. Please complete OTP verification.'
      });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        success: false,
        error: passwordValidation.error
      });
    }

    await client.query('BEGIN');

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Generate registration number if not provided
    const schoolPrefix = schoolName.substring(0, 3).toUpperCase();
    const finalRegNumber = registrationNumber || `${schoolPrefix}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

    // Create student
    const studentResult = await client.query(
      `INSERT INTO students (
        school_id, first_name, last_name, email, password_hash,
        registration_number, phone, date_of_birth, gender, address
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id, school_id, first_name, last_name, email, registration_number, phone, date_of_birth, gender, address, created_at`,
      [schoolId, firstName, lastName, normalizedEmail, passwordHash, finalRegNumber, phone || null, dateOfBirth || null, gender || null, address || null]
    );

    // Clean up verification record
    await client.query('DELETE FROM email_verifications WHERE email = $1', [normalizedEmail]);

    await client.query('COMMIT');

    const student = studentResult.rows[0];

    // Generate JWT token
    const token = jwt.sign(
      {
        studentId: student.id,
        schoolId: student.school_id,
        type: 'student'
      },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(201).json({
      success: true,
      message: 'Student account created successfully',
      data: {
        student,
        token
      }
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Student Registration Error:', error.message);

    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        error: 'Registration number or email already exists'
      });
    }

    res.status(500).json({
      success: false,
      error: error.message
    });
  } finally {
    client.release();
  }
});

/**
 * @route   POST /api/students/login
 * @desc    Student login
 * @access  Public
 * @body    {
 *            email: String (required),
 *            password: String (required)
 *          }
 */
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required'
      });
    }

    // Find student by email
      const normalizedEmail = email.trim().toLowerCase();
      const result = await pool.query(
        `SELECT 
          s.id, s.school_id, s.first_name, s.last_name, s.email, 
          s.registration_number, s.password_hash, s.phone, s.date_of_birth, 
          s.gender, s.photo, s.address,
          sc.name as school_name,
          sc.country_id as school_country_id,
          sc.country as school_country_name,
          sc.phone as school_phone,
          sc.email as school_email
        FROM students s
        JOIN schools sc ON s.school_id = sc.id
        WHERE s.email = $1`,
        [normalizedEmail]
      );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    const student = result.rows[0];

    // Check if password_hash exists (for students imported via bulk)
    if (!student.password_hash) {
      return res.status(401).json({
        success: false,
        error: 'Account not activated. Please contact your school administrator.'
      });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, student.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    // Resolve countryId: prefer school's country_id, otherwise lookup by school's country name
    let resolvedCountryId = student.school_country_id || null;
    if (!resolvedCountryId && student.school_country_name) {
      try {
        const countryLookup = await pool.query(
          'SELECT id FROM countries WHERE LOWER(name) = LOWER($1) LIMIT 1',
          [student.school_country_name.trim()]
        );
        if (countryLookup.rows.length > 0) {
          resolvedCountryId = countryLookup.rows[0].id;
        }
      } catch (err) {
        console.warn('Country lookup failed:', err.message || err);
      }
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        studentId: student.id,
        registrationNumber: student.registration_number,
        schoolId: student.school_id,
        countryId: resolvedCountryId,
        type: 'student'
      },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Remove password_hash from response
    delete student.password_hash;

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        student: {
          ...student,
          type: 'student'  // Include type for client-side routing
        },
        token
      }
    });

  } catch (error) {
    console.error('Student Login Error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/students/profile
 * @desc    Update student's own profile
 * @access  Private (Student only)
 * @body    {
 *            firstName: String (optional),
 *            lastName: String (optional),
 *            email: String (optional),
 *            phone: String (optional),
 *            dateOfBirth: String (optional),
 *            gender: String (optional),
 *            photo: String (optional),
 *            currentPassword: String (required if changing password),
 *            newPassword: String (optional)
 *          }
 */


/**
 * @route   GET /api/students/me/enrollments
 * @desc    Get logged-in student's enrollment history
 * @access  Private (Student) - Requires Active Subscription
 */
router.get('/me/enrollments', authMiddleware.authenticateToken, authMiddleware.requireStudent, checkSubscription, async (req, res) => {
  try {
    if (req.user?.type !== 'student') {
      return res.status(403).json({ success: false, error: 'This endpoint is for students only' });
    }

    const studentId = req.user.studentId;
    const schoolId = req.user.schoolId;

    // Use academic_years table and select both label and name as provided
    const query = `
      SELECT 
        e.id as enrollment_id,
        ay.id as session_id,
        ay.year_label as academic_year_label,
        ay.session_name as academic_session,
        e.status as enrollment_status,
        e.class_id,
        c.class_name as class_name,
        e.created_at
      FROM enrollments e
      JOIN classes c ON e.class_id = c.id
      JOIN academic_years ay ON e.session_id = ay.id
      WHERE e.student_id = $1 AND e.school_id = $2
      ORDER BY ay.year_label DESC, e.created_at DESC`;

    const result = await pool.query(query, [studentId, schoolId]);

    res.json({
      success: true,
      data: result.rows,
      count: result.rowCount
    });
  } catch (error) {
    console.error('My Enrollments Error:', error.message); // Log full error for debugging
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * @route   GET /api/students/me/enrollments/:sessionId
 * @desc    Get details for a specific session enrollment
 * @access  Private (Student) - Requires Active Subscription
 */
router.get('/me/enrollments/:sessionId', authMiddleware.authenticateToken, authMiddleware.requireStudent, checkSubscription, async (req, res) => {
  try {
    if (req.user?.type !== 'student') {
      return res.status(403).json({ success: false, error: 'This endpoint is for students only' });
    }

    const { sessionId } = req.params;
    const studentId = req.user.studentId;
    const schoolId = req.user.schoolId;

    const query = `
      SELECT 
        e.id as enrollment_id,
        ay.id as session_id,
        ay.year_label as academic_year_label,
        ay.session_name as academic_session,
        e.status as enrollment_status,
        e.class_id,
        c.class_name as class_name,
        e.created_at
      FROM enrollments e
      JOIN classes c ON e.class_id = c.id
      JOIN academic_years ay ON e.session_id = ay.id
      WHERE e.student_id = $1 AND e.school_id = $2 AND ay.id = $3
      ORDER BY e.created_at DESC`;

    const result = await pool.query(query, [studentId, schoolId, sessionId]);

    res.json({
      success: true,
      data: result.rows,
      count: result.rowCount
    });
  } catch (error) {
    console.error('Session Enrollments Error:', error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});


/**
 * @route   PUT /api/students/profile
 * @desc    Update student's own profile (includes photo upload)
 * @access  Private (Student only)
 */
router.put('/profile', authMiddleware.authenticateToken, authMiddleware.requireStudent, upload.single('photo'), async (req, res) => {
  const client = await pool.connect();

  try {
    // Verify this is a student token
    if (req.user?.type !== 'student') {
      return res.status(403).json({
        success: false,
        error: 'This endpoint is for students only'
      });
    }

    const studentId = req.user?.studentId;
    let {
      firstName, lastName, email, phone, dateOfBirth,
      gender, address, currentPassword, newPassword
    } = req.body;

    // Sanitized logging
    console.log('👤 Profile Update Request - Student:', studentId);
    console.log('📁 File:', req.file ? { name: req.file.originalname, size: req.file.size } : 'No file');

    let photo = null; // Default to null so COALESCE keeps old value if no update provided

    // Validation
    if (dateOfBirth) {
      // Format check (YYYY-MM-DD)
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!dateRegex.test(dateOfBirth)) {
        return res.status(400).json({
          success: false,
          error: 'Invalid Date of Birth format. Please use YYYY-MM-DD'
        });
      }

      const dob = new Date(dateOfBirth);
      if (isNaN(dob.getTime())) {
        return res.status(400).json({
          success: false,
          error: 'The provided Date of Birth is not a valid date'
        });
      }

      if (dob > new Date()) {
        return res.status(400).json({
          success: false,
          error: 'Date of Birth cannot be in the future'
        });
      }
    }

    if (firstName !== undefined && firstName.trim() === '') {
      return res.status(400).json({ success: false, error: 'First name cannot be empty' });
    }
    if (lastName !== undefined && lastName.trim() === '') {
      return res.status(400).json({ success: false, error: 'Last name cannot be empty' });
    }

    // 1. Handle File Upload (Multer + @vercel/blob)
    if (req.file) {
      try {
        console.log(`📸 Uploading profile photo for student ${studentId}...`);
        const file = req.file;

        // Validate file size (max 5MB)
        const MAX_SIZE = 5 * 1024 * 1024;
        if (file.size > MAX_SIZE) {
          return res.status(400).json({ success: false, error: 'Photo is too large (max 5MB)' });
        }

        const cleanFileName = file.originalname.replace(/\s+/g, '-');
        const uniqueFileName = `student-${studentId}-profile-${Date.now()}-${cleanFileName}`;

        const blob = await put(uniqueFileName, file.buffer, {
          access: 'public',
          token: process.env.BLOB_READ_WRITE_TOKEN
        });

        photo = blob.url;
        console.log('✅ Photo upload successful:', photo);
      } catch (uploadError) {
        console.error('❌ Photo upload failed:', uploadError);
        return res.status(500).json({ success: false, error: 'Failed to upload photo: ' + uploadError.message });
      }
    }
    // 2. Handle passed string URL (if any, though usually we keep old one if no new file)
    else if (req.body.photo && typeof req.body.photo === 'string' && !req.body.photo.startsWith('[object')) {
      photo = req.body.photo;
    }

    await client.query('BEGIN');

    // If changing password, verify current password
    if (newPassword) {
      if (!currentPassword) {
        return res.status(400).json({
          success: false,
          error: 'Current password is required to set a new password'
        });
      }

      const studentResult = await client.query(
        'SELECT password_hash FROM students WHERE id = $1',
        [studentId]
      );

      if (studentResult.rows.length === 0) {
        return res.status(404).json({
          success: false,
          error: 'Student not found'
        });
      }

      const isValidPassword = await bcrypt.compare(currentPassword, studentResult.rows[0].password_hash);

      if (!isValidPassword) {
        return res.status(401).json({
          success: false,
          error: 'Current password is incorrect'
        });
      }

      // Hash new password
      const newPasswordHash = await bcrypt.hash(newPassword, 10);

      await client.query(
        'UPDATE students SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [newPasswordHash, studentId]
      );
    }

    // Update other fields
    const result = await client.query(
      `UPDATE students SET
       first_name = COALESCE($1, first_name),
       last_name = COALESCE($2, last_name),
       email = COALESCE($3, email),
       phone = COALESCE($4, phone),
       date_of_birth = COALESCE($5, date_of_birth),
       gender = COALESCE($6, gender),
       photo = COALESCE($7, photo),
       address = COALESCE($8, address),
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $9
       RETURNING id, school_id, first_name, last_name, email, registration_number, phone, date_of_birth, gender, photo, address, updated_at`,
      [firstName, lastName, email, phone, dateOfBirth, gender, photo, address, studentId]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'Student not found'
      });
    }

    await client.query('COMMIT');

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Profile Update Error:', error);

    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        error: 'Email already in use'
      });
    }

    res.status(500).json({
      success: false,
      error: error.message
    });
  } finally {
    client.release();
  }
});

// =====================================================================
// ADMIN STUDENT MANAGEMENT ENDPOINTS (Require Admin Authentication)
// =====================================================================

/**
 * @route   GET /api/students/enrollments
 * @desc    Get all student enrollments for the authenticated school
 *          Returns full enrollment detail: enrollmentId, studentId, classId, sessionId, status, student info, class name, session name
 * @access  Private (School only)
 * @query   status    - optional filter: 'active' | 'promoted' | 'repeated' | 'transferred' | 'graduated'
 * @query   classId   - optional filter by class
 * @query   sessionId - optional filter by academic session
 */
router.get('/enrollments', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    // STRICT SECURITY: Extract schoolId ONLY from token, never from req.body or req.query
    const schoolId = req.user?.schoolId;

    if (!schoolId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    // Optional query filters
    const { status, classId, sessionId } = req.query;

    console.log(`📥 GET /students/enrollments - School: ${schoolId} | Filters: status=${status}, classId=${classId}, sessionId=${sessionId}`);

    // Build dynamic WHERE clause from optional filters
    const conditions = ['e.school_id = $1'];
    const params = [schoolId];
    let paramIndex = 2;

    if (status) {
      conditions.push(`e.status = $${paramIndex++}`);
      params.push(status);
    }

    // A class-scoped teacher only ever sees their own class's enrollments
    // — an explicit classId filter from them is still honored, but only
    // if it matches their assigned class (silently narrowed rather than
    // erroring, since this is a read/filter, not a write).
    const scopedClassId = authMiddleware.getTeacherClassScope(req);
    if (scopedClassId) {
      conditions.push(`e.class_id = $${paramIndex++}`);
      params.push(scopedClassId);
    } else if (classId) {
      conditions.push(`e.class_id = $${paramIndex++}`);
      params.push(classId);
    }

    if (sessionId) {
      conditions.push(`e.session_id = $${paramIndex++}`);
      params.push(sessionId);
    }

    const whereClause = conditions.join(' AND ');

    const query = `
      SELECT
        e.id                    AS enrollment_id,
        e.school_id,
        e.student_id,
        e.class_id,
        e.session_id,
        e.status                AS enrollment_status,
        e.created_at            AS enrolled_at,

        -- Student details
        s.first_name,
        s.last_name,
        s.email,
        s.registration_number,
        s.gender,
        s.phone,
        s.photo,

        -- Class details
        c.class_name             AS class_name,

        -- Academic session details
        ay.session_name         AS academic_session,
        ay.year_label           AS academic_year

      FROM enrollments e
      JOIN students              s   ON e.student_id  = s.id
      JOIN classes                c ON e.class_id   = c.id
      JOIN academic_years        ay  ON e.session_id  = ay.id

      WHERE ${whereClause}
      ORDER BY ay.year_label DESC, c.class_name ASC, s.last_name ASC, s.first_name ASC
    `;

    const result = await pool.query(query, params);

    console.log(`✅ Retrieved ${result.rowCount} enrollments for school ${schoolId}`);

    res.status(200).json({
      success: true,
      count: result.rowCount,
      filters: { status: status || null, classId: classId || null, sessionId: sessionId || null },
      data: result.rows
    });

  } catch (error) {
    console.error('❌ Get School Enrollments Error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * @route   DELETE /api/students/enrollments/:enrollmentId
 * @desc    Delete a specific enrollment record by its ID
 * @access  Private (School only)
 * @param   enrollmentId - the specific enrollment to remove (get this from GET /students/enrollments)
 */
router.delete('/enrollments/:enrollmentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, authMiddleware.requireOwner, async (req, res) => {
  const client = await pool.connect();

  try {
    // STRICT SECURITY: Extract schoolId ONLY from token, never from req.body or req.query
    const schoolId = req.user?.schoolId;
    const { enrollmentId } = req.params;

    if (!schoolId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    if (!enrollmentId || isNaN(enrollmentId)) {
      return res.status(400).json({
        success: false,
        error: 'A valid enrollmentId is required.'
      });
    }

    console.log(`📥 DELETE /students/enrollments/${enrollmentId} - School: ${schoolId}`);

    await client.query('BEGIN');

    // Fetch the enrollment first — confirm it belongs to this school
    const enrollmentCheck = await client.query(
      `SELECT 
         e.id, e.student_id, e.class_id, e.session_id, e.status,
         s.first_name, s.last_name,
         c.class_name AS class_name,
         ay.session_name  AS academic_session
       FROM enrollments e
       JOIN students               s   ON e.student_id = s.id
       JOIN classes                c ON e.class_id   = c.id
       JOIN academic_years         ay  ON e.session_id = ay.id
       WHERE e.id = $1 AND e.school_id = $2`,
      [enrollmentId, schoolId]
    );

    if (enrollmentCheck.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'Enrollment not found or does not belong to your school.'
      });
    }

    const enrollment = enrollmentCheck.rows[0];

    // Delete the specific enrollment
    await client.query(
      'DELETE FROM enrollments WHERE id = $1 AND school_id = $2',
      [enrollmentId, schoolId]
    );

    await client.query('COMMIT');

    console.log(`✅ Enrollment ${enrollmentId} deleted - Student: ${enrollment.first_name} ${enrollment.last_name}, Class: ${enrollment.class_name}, Session: ${enrollment.academic_session}`);

    res.status(200).json({
      success: true,
      message: `Enrollment removed successfully.`,
      data: {
        deletedEnrollmentId: parseInt(enrollmentId),
        studentId: enrollment.student_id,
        studentName: `${enrollment.first_name} ${enrollment.last_name}`,
        class: enrollment.class_name,
        session: enrollment.academic_session
      }
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Delete Enrollment Error:', error);
    res.status(500).json({ success: false, error: error.message });
  } finally {
    client.release();
  }
});


/**
 * @route   POST /api/students/bulk
 * @desc    Bulk create students for the authenticated school with automatic enrollment
 * @access  Private
 * @body    {
 *            students: [
 *              {
 *                firstName: String,
 *                lastName: String,
 *                email: String (optional),
 *                phone: String (optional),
 *                dateOfBirth: String (optional, YYYY-MM-DD),
 *                classId: Number (required for auto-enrollment),
 *                studentNumber: String (optional, auto-generated using school name prefix),
 *                gender: String (optional)
 *              }
 *            ],
 *            academicSession: String (required, e.g., "2023/2024")
 *          }
 */
router.post('/bulk', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  const client = await pool.connect();

  try {
    // STRICT SECURITY: Extract schoolId and countryId ONLY from token, never from req.body or req.query
    const schoolId = req.user?.schoolId;
    const countryId = req.user?.countryId;
    const { students, academicSession } = req.body; // e.g., "2044/2045"

    if (!schoolId) {
      return res.status(401).json({ success: false, error: 'Authentication context missing. Please login again.' });
    }

    if (!countryId) {
      return res.status(401).json({ success: false, error: 'Country context missing. Please login again.' });
    }

    if (!students || !Array.isArray(students)) {
      return res.status(400).json({ success: false, error: 'Invalid students list' });
    }

    if (!academicSession) {
      return res.status(400).json({ success: false, error: 'Academic session required (e.g., "2023/2024")' });
    }

    await client.query('BEGIN');

    // A class-scoped teacher (see middleware/auth.js -> getTeacherClassScope)
    // may only bulk-create students into their own assigned class — checked
    // once, up front, so a single bad row rolls back the whole batch rather
    // than partially succeeding.
    const scopedClassId = authMiddleware.getTeacherClassScope(req);
    if (scopedClassId) {
      const offendingRow = students.findIndex((s) => Number(s.classId) !== Number(scopedClassId));
      if (offendingRow !== -1) {
        await client.query('ROLLBACK');
        return res.status(403).json({
          success: false,
          error: `Row ${offendingRow + 1}: you can only add students to your assigned class.`,
          code: 'CLASS_SCOPE_VIOLATION',
        });
      }
    }

    // Get school name for registration number prefix
    const schoolLookup = await client.query(
      'SELECT name FROM schools WHERE id = $1 LIMIT 1',
      [schoolId]
    );

    if (schoolLookup.rows.length === 0) {
      throw new Error('School not found.');
    }

    const schoolName = schoolLookup.rows[0].name;
    const schoolPrefix = schoolName.substring(0, 3).toUpperCase();

    // 1. Convert the session string "2044/2045" into the actual database ID
    // academic_years is a global table (not school-specific)
    const sessionLookup = await client.query(
      'SELECT id FROM academic_years WHERE session_name = $1 LIMIT 1',
      [academicSession]
    );

    if (sessionLookup.rows.length === 0) {
      throw new Error(`Academic session "${academicSession}" not found. Please ensure the session exists in your school.`);
    }

    const sessionId = sessionLookup.rows[0].id;
    const results = [];

    for (const [index, s] of students.entries()) {
      if (!s.firstName || !s.lastName || !s.classId) {
        throw new Error(`Row ${index + 1}: Name and Class ID are required.`);
      }

      // Verify classId belongs to THIS school — `classes` is the real,
      // school-scoped table (matches the FK enrollments.class_id
      // actually references), not global_class_templates, which is a
      // different, country-scoped id space. Clients should be sourcing
      // classId from GET /api/classes/school, never GET /api/classes.
      const classCheck = await client.query(
        'SELECT id FROM classes WHERE id = $1 AND school_id = $2',
        [s.classId, schoolId]
      );

      if (classCheck.rows.length === 0) {
        throw new Error(`Row ${index + 1}: Class ID ${s.classId} is invalid or does not belong to your school.`);
      }

      // Create Student with auto-generated password "1234567890"
      const studentNum = s.studentNumber || `${schoolPrefix}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const defaultPassword = '1234567890';
      const passwordHash = await bcrypt.hash(defaultPassword, 10);

      const studentInsert = await client.query(
        `INSERT INTO students (school_id, first_name, last_name, email, phone, date_of_birth, registration_number, gender, password_hash) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
        [schoolId, s.firstName, s.lastName, s.email || null, s.phone || null, s.dateOfBirth || null, studentNum, s.gender || null, passwordHash]
      );

      const studentId = studentInsert.rows[0].id;

      // 2. Insert Enrollment with the school's actual class_id (from classes table)
      // using the session_id (from academic_years table)
      const enrollmentInsert = await client.query(
        `INSERT INTO enrollments (school_id, student_id, class_id, session_id, status)
         VALUES ($1, $2, $3, $4, 'active') RETURNING id`,
        [schoolId, studentId, s.classId, sessionId]
      );

      results.push({
        name: `${s.firstName} ${s.lastName}`,
        studentId: studentId,
        enrollmentId: enrollmentInsert.rows[0].id,
        classId: s.classId
      });
    }

    await client.query('COMMIT');
    res.status(201).json({
      success: true,
      message: `Successfully created and enrolled ${results.length} students`,
      count: results.length,
      data: results
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error("❌ Bulk Processing Error:", error);

    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        error: 'A student with this registration number or email already exists.'
      });
    }

    res.status(500).json({ success: false, error: error.message });
  } finally {
    client.release();
  }
});
/**
 * @route   POST /api/students
 * @desc    Create a single student with automatic enrollment
 * @access  Private
 * @body    {
 *            firstName: String (required),
 *            lastName: String (required),
 *            classId: Number (required for auto-enrollment),
 *            email: String (optional),
 *            registrationNumber: String (optional),
 *            gender: String (optional),
 *            dateOfBirth: String (optional),
 *            phone: String (optional),
 *            photo: String (optional)
 *          }
 */


router.post('/', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription,
  authMiddleware.enforceClassScope((req) => req.body?.classId),
  auditRoute('student.created', (req, body) => ({
    type: 'student',
    id: body?.data?.student?.id,
    details: { name: `${req.body?.firstName || ''} ${req.body?.lastName || ''}`.trim() }
  })),
  async (req, res) => {
  const client = await pool.connect();

  try {
    const schoolId = req.user?.schoolId;
    const {
      firstName, lastName, email, registrationNumber,
      gender, dateOfBirth, phone, photo, classId
    } = req.body;

    if (!firstName || !lastName) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: 'First and Last names are required'
      });
    }

    // if (!classId) {
    //   return res.status(400).json({ 
    //     success: false, 
    //     message: 'Validation Error', 
    //     error: 'classId is required for automatic enrollment' 
    //   });
    // }

    // Begin transaction
    await client.query('BEGIN');

    const finalRegNumber = registrationNumber || `STU-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

    // Insert student
    const studentResult = await client.query(
      `INSERT INTO students (
        school_id, first_name, last_name, email, 
        registration_number, gender, date_of_birth, phone, photo
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`,
      [schoolId, firstName, lastName, email || null, finalRegNumber,
        gender || null, dateOfBirth || null, phone || null, photo || null]
    );

    const student = studentResult.rows[0];

    // Verify class belongs to school
    const classCheck = await client.query(
      'SELECT id FROM classes WHERE id = $1 AND school_id = $2',
      [classId, schoolId]
    );

    // if (classCheck.rows.length === 0) {
    //   await client.query('ROLLBACK');
    //   return res.status(403).json({
    //     success: false,
    //     message: 'Unauthorized',
    //     error: 'Class not found in your school'
    //   });
    // }

    // Get school's active session from academic_years
    const sessionResult = await client.query(
      'SELECT id FROM academic_years WHERE is_active = true LIMIT 1'
    );

    if (sessionResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Configuration Error',
        error: 'No active academic year found. Please set up an active academic year first.'
      });
    }

    const sessionId = sessionResult.rows[0].id;

    // Auto-enroll student in their class for active session
    const enrollmentResult = await client.query(
      `INSERT INTO enrollments (
        school_id, student_id, class_id, session_id, status
      ) VALUES ($1, $2, $3, $4, 'active')
      RETURNING *`,
      [schoolId, student.id, classId, sessionId]
    );

    const enrollment = enrollmentResult.rows[0];

    // Commit transaction
    await client.query('COMMIT');

    res.status(201).json({
      success: true,
      message: 'Student created and auto-enrolled successfully',
      data: {
        student,
        enrollment
      }
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error("Single Create Error:", error.message);
    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'Conflict',
        error: 'Duplicate registration number detected.'
      });
    }
    res.status(500).json({ success: false, message: 'Server Error', error: error.message });
  } finally {
    client.release();
  }
});

/**
 * @route   GET /api/students
 * @desc    Fetch all students for the authenticated school with current enrollment info
 * @access  Private
 * @query   sessionId (optional) - Filter by specific session; defaults to active session
 */
// router.get('/', async (req, res) => {
//   try {
//     const schoolId = req.user?.schoolId;
//     const { sessionId } = req.query;

//     let params = [schoolId];
//     let sessionIdValue = sessionId;

//     // If no sessionId provided, fetch the active session
//     if (!sessionIdValue) {
//       const sessionResult = await pool.query(
//         'SELECT id FROM academic_sessions WHERE school_id = $1 AND is_active = true LIMIT 1',
//         [schoolId]
//       );
//       if (sessionResult.rows.length > 0) {
//         sessionIdValue = sessionResult.rows[0].id;
//       }
//     }

//     params.push(sessionIdValue);

//     // JOIN students with enrollments to include enrollment_id and class info
//     const result = await pool.query(
//       `SELECT 
//         s.id,
//         s.school_id,
//         s.first_name,
//         s.last_name,
//         s.email,
//         s.registration_number,
//         s.date_of_birth,
//         s.gender,
//         s.phone,
//         s.photo,
//         e.id as enrollment_id,
//         e.class_id,
//         e.session_id,
//         e.status as enrollment_status,
//         c.class_name
//        FROM students s
//        LEFT JOIN enrollments e ON s.id = e.student_id AND e.school_id = $1
//        LEFT JOIN classes c ON e.class_id = c.id
//        WHERE s.school_id = $1 
//        ${sessionIdValue ? 'AND e.session_id = $2' : ''}
//        ORDER BY s.last_name ASC, s.first_name ASC`, 
//       sessionIdValue ? params : [schoolId]
//     );

//     return res.status(200).json({
//       success: true,
//       count: result.rowCount,
//       data: result.rows
//     });

//   } catch (error) {
//     console.error("Fetch Error:", error.message);
//     return res.status(500).json({ success: false, message: "Failed to fetch students", error: error.message });
//   }
// });





/**
 * @route   GET /api/students
 * @desc    Get all students registered to the authenticated school
 * @access  Private
 */
router.get('/', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;

    if (!schoolId) {
      return res.status(401).json({ success: false, message: "Unauthorized: No school ID found in token" });
    }

    // A class-scoped teacher only ever sees their own class's roster —
    // consistent with the write-side restriction on POST / and
    // POST /enrollments/create above. Owners, full admins, and
    // teachers with no class assigned see the whole school (unchanged).
    const scopedClassId = authMiddleware.getTeacherClassScope(req);
    const classFilterClause = scopedClassId ? 'AND e.class_id = $2' : '';
    const queryParams = scopedClassId ? [schoolId, scopedClassId] : [schoolId];

    // This query selects ALL students belonging to the school.
    // It uses a subquery with DISTINCT ON to ensure each student appears only once,
    // picking their most recent enrollment information if they have multiple.
    const query = `
      SELECT * FROM (
        SELECT DISTINCT ON (s.id)
          s.id,
          s.first_name,
          s.last_name,
          s.date_of_birth,
          s.registration_number,
          s.gender,
          s.email,
          s.phone,
          e.id as enrollment_id,
          e.status as enrollment_status,
          e.class_id,
          c.class_name as class_name,
          ay.year_label as academic_session
        FROM students s
        LEFT JOIN enrollments e ON s.id = e.student_id AND e.school_id = s.school_id
        LEFT JOIN classes c ON e.class_id = c.id
        LEFT JOIN academic_years ay ON e.session_id = ay.id
        WHERE s.school_id = $1 ${classFilterClause}
        ORDER BY s.id, ay.year_label DESC NULLS LAST
      ) AS unique_students
      ORDER BY last_name ASC, first_name ASC
    `;

    const result = await pool.query(query, queryParams);

    return res.status(200).json({
      success: true,
      count: result.rowCount,
      data: result.rows
    });

  } catch (error) {
    console.error("Fetch All Students Error:", error.message);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch student list",
      error: error.message
    });
  }
});
/**
 * @route   GET /api/students/:studentId
 * @desc    Fetch a specific student's details with enrollment history
 * @access  Private
 */
router.get('/:studentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;

    const result = await pool.query(
      `SELECT * FROM students WHERE id = $1 AND school_id = $2`,
      [studentId, schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Student not found or unauthorized' });
    }

    // Get enrollment history for this student
    const enrollmentResult = await pool.query(
      `SELECT 
          e.id as enrollment_id,
          ay.session_name as academic_session,
          e.status,
          c.class_name,
          e.created_at,
          e.updated_at
        FROM enrollments e
        JOIN classes c ON e.class_id = c.id
        JOIN academic_years ay ON e.session_id = ay.id
        WHERE e.student_id = $1 AND e.school_id = $2
        ORDER BY ay.year_label DESC`,
      [studentId, schoolId]
    );

    res.json({
      success: true,
      data: {
        student: result.rows[0],
        enrollmentHistory: enrollmentResult.rows
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Fetch failed', error: error.message });
  }
});

/**
 * @route   PUT /api/students/:studentId
 * @desc    Update student details
 * @access  Private
 */
router.put('/:studentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription,
  auditRoute('student.updated', (req) => ({ type: 'student', id: req.params.studentId })),
  async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;
    const data = req.body;

    // A class-scoped teacher may only edit students currently enrolled
    // in their own class. Checked here (rather than via
    // enforceClassScope) because the relevant classId isn't in the
    // request body — it's the student's *existing* enrollment.
    const scopedClassId = authMiddleware.getTeacherClassScope(req);
    if (scopedClassId) {
      const enrollmentCheck = await pool.query(
        `SELECT 1 FROM enrollments WHERE student_id = $1 AND school_id = $2 AND class_id = $3 LIMIT 1`,
        [studentId, schoolId, scopedClassId]
      );
      if (enrollmentCheck.rows.length === 0) {
        return res.status(403).json({
          success: false,
          error: 'You can only edit students in your assigned class.',
          code: 'CLASS_SCOPE_VIOLATION',
        });
      }
    }

    const result = await pool.query(
      `UPDATE students SET
       first_name = COALESCE($1, first_name),
       last_name = COALESCE($2, last_name),
       email = COALESCE($3, email),
       registration_number = COALESCE($4, registration_number),
       date_of_birth = COALESCE($5, date_of_birth),
       gender = COALESCE($6, gender),
       phone = COALESCE($7, phone),
       photo = COALESCE($8, photo),
       updated_at = CURRENT_TIMESTAMP
       WHERE id = $9 AND school_id = $10
       RETURNING *`,
      [
        data.firstName, data.lastName, data.email, data.registrationNumber,
        data.dateOfBirth, data.gender, data.phone, data.photo,
        studentId, schoolId
      ]
    );

    if (result.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Student not found or unauthorized' });
    }

    res.json({
      success: true,
      message: 'Student updated successfully',
      data: result.rows[0]
    });
  } catch (error) {
    console.error("Update Error:", error.message);

    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'Conflict',
        error: 'This registration number or email is already assigned to another student.'
      });
    }

    res.status(500).json({ success: false, message: 'Update failed', error: error.message });
  }
});

/**
 * @route   DELETE /api/students/:studentId
 * @desc    Remove a student record (cascades to enrollments & scores)
 * @access  Private
 */
router.delete('/:studentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, authMiddleware.requireOwner, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;

    const result = await pool.query(
      'DELETE FROM students WHERE id = $1 AND school_id = $2 RETURNING id',
      [studentId, schoolId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Student not found or unauthorized' });
    }

    res.json({ success: true, message: 'Student record deleted successfully' });
  } catch (error) {
    console.error("Delete Error:", error.message);
    res.status(500).json({ success: false, message: 'Delete failed', error: error.message });
  }
});

// =====================================================================
// ENROLLMENT MANAGEMENT ENDPOINTS
// =====================================================================

/**
 * @route   POST /api/students/enrollments/create
 * @desc    Create or update an enrollment record (assign student to class for a session)
 * @access  Private
 * @body    {
 *            studentId: Number,
 *            classId: Number,
 *            sessionId: Number (ID from academic_years table),
 *            status: String (optional: "active", "promoted", "repeated", "transferred", "graduated")
 *          }
 */
router.post('/enrollments/create', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription,
  authMiddleware.enforceClassScope((req) => req.body?.classId),
  async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { studentId, classId, sessionId, status = 'active' } = req.body;

    // Validation
    if (!studentId || !classId || !sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: 'studentId, classId, and sessionId are required'
      });
    }

    const validStatuses = ['active', 'promoted', 'repeated', 'transferred', 'graduated'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: `Status must be one of: ${validStatuses.join(', ')}`
      });
    }

    // Verify student belongs to school
    const studentCheck = await pool.query(
      'SELECT id FROM students WHERE id = $1 AND school_id = $2',
      [studentId, schoolId]
    );

    if (studentCheck.rows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
        error: 'Student not found in your school'
      });
    }

    // Verify class belongs to school
    const classCheck = await pool.query(
      'SELECT id FROM classes WHERE id = $1 AND school_id = $2',
      [classId, schoolId]
    );

    if (classCheck.rows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
        error: 'Class not found in your school'
      });
    }

    // Verify academic session belongs to global academic_years
    const sessionCheck = await pool.query(
      'SELECT id FROM academic_years WHERE id = $1',
      [sessionId]
    );

    if (sessionCheck.rows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
        error: 'Academic session not found in your school'
      });
    }

    // Upsert enrollment record
    const result = await pool.query(
      `INSERT INTO enrollments (
        school_id, student_id, class_id, session_id, status
      ) VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (school_id, student_id, class_id, session_id)
      DO UPDATE SET
        status = $5,
        updated_at = CURRENT_TIMESTAMP
      RETURNING *`,
      [schoolId, studentId, classId, sessionId, status]
    );

    res.status(201).json({
      success: true,
      message: 'Enrollment record saved successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Enrollment Create Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/students/enrollments/bulk
 * @desc    Bulk create enrollments for multiple students
 * @access  Private
 * @body    {
 *            enrollments: [
 *              {
 *                studentId: Number,
 *                classId: Number,
 *                sessionId: Number (ID from academic_years table),
 *                status: String (optional)
 *              },
 *              ...more enrollments
 *            ]
 *          }
 */
router.post('/enrollments/bulk', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { enrollments } = req.body;

    if (!enrollments || !Array.isArray(enrollments) || enrollments.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: 'Enrollments must be a non-empty array'
      });
    }

    // Validate all enrollments before processing
    for (let i = 0; i < enrollments.length; i++) {
      const enrollment = enrollments[i];
      if (!enrollment.studentId || !enrollment.classId || !enrollment.sessionId) {
        return res.status(400).json({
          success: false,
          message: 'Validation Error',
          error: `Enrollment at index ${i} is missing required fields (studentId, classId, sessionId)`
        });
      }
    }

    // Build bulk insert query
    const values = [];
    const placeholders = enrollments.map((enrollment, i) => {
      const offset = i * 5;
      const status = enrollment.status || 'active';

      values.push(
        schoolId,
        enrollment.studentId,
        enrollment.classId,
        enrollment.sessionId,
        status
      );

      return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5})`;
    }).join(',');

    const query = `
      INSERT INTO enrollments (
        school_id, student_id, class_id, session_id, status
      ) VALUES ${placeholders}
      ON CONFLICT (school_id, student_id, class_id, session_id)
      DO UPDATE SET
        status = EXCLUDED.status,
        updated_at = CURRENT_TIMESTAMP
      RETURNING *`;

    const result = await pool.query(query, values);

    res.status(201).json({
      success: true,
      message: `Successfully created/updated ${result.rowCount} enrollment records`,
      count: result.rowCount,
      data: result.rows
    });

  } catch (error) {
    console.error('Bulk Enrollment Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/students/enrollments/class/:classId
 * @desc    Get all enrollments for a specific class in an academic session
 * @access  Private
 * @query   {
 *            sessionId: Number (required, ID from academic_years table)
 *          }
 */
router.get('/enrollments/class/:classId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { classId } = req.params;
    const { sessionId } = req.query;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: 'sessionId query parameter is required'
      });
    }

    const result = await pool.query(
      `SELECT
        e.id as enrollment_id,
        e.student_id,
        s.first_name,
        s.last_name,
        s.registration_number,
        ay.session_name as academic_session,
        e.status,
        e.created_at,
        e.updated_at
      FROM enrollments e
      JOIN students s ON e.student_id = s.id
      JOIN academic_years ay ON e.session_id = ay.id
      WHERE e.class_id = $1 AND e.school_id = $2 AND e.session_id = $3
      ORDER BY s.last_name ASC, s.first_name ASC`,
      [classId, schoolId, sessionId]
    );

    res.status(200).json({
      success: true,
      count: result.rowCount,
      message: `Retrieved ${result.rowCount} enrollments for the class`,
      data: result.rows
    });

  } catch (error) {
    console.error('Class Enrollments Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/students/:studentId/enrollments
 * @desc    Get all enrollments for a specific student (complete enrollment history)
 * @access  Private
 */
router.get('/:studentId/enrollments', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;

    // Verify student belongs to school
    const studentCheck = await pool.query(
      'SELECT id FROM students WHERE id = $1 AND school_id = $2',
      [studentId, schoolId]
    );

    if (studentCheck.rows.length === 0) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
        error: 'Student not found in your school'
      });
    }

    const result = await pool.query(
      `SELECT
        e.id as enrollment_id,
        ay.session_name as academic_session,
        e.status,
        c.id as class_id,
        c.class_name,
        e.created_at,
        e.updated_at
      FROM enrollments e
      JOIN classes c ON e.class_id = c.id
      JOIN academic_years ay ON e.session_id = ay.id
      WHERE e.student_id = $1 AND e.school_id = $2
      ORDER BY ay.year_label DESC`,
      [studentId, schoolId]
    );

    res.status(200).json({
      success: true,
      count: result.rowCount,
      message: `Retrieved ${result.rowCount} enrollment records for student`,
      data: result.rows
    });

  } catch (error) {
    console.error('Student Enrollments Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/students/enrollments/:enrollmentId
 * @desc    Update an enrollment record (change status or class)
 * @access  Private
 * @body    {
 *            classId: Number (optional),
 *            status: String (optional)
 *          }
 */
router.put('/enrollments/:enrollmentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const schoolId = req.user?.schoolId;
    const { enrollmentId } = req.params;
    const { classId, status } = req.body;

    if (!classId && !status) {
      return res.status(400).json({
        success: false,
        message: 'Validation Error',
        error: 'At least one of classId or status must be provided'
      });
    }

    if (status) {
      const validStatuses = ['active', 'promoted', 'repeated', 'transferred', 'graduated'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: 'Validation Error',
          error: `Status must be one of: ${validStatuses.join(', ')}`
        });
      }
    }

    // Verify enrollment belongs to school
    const enrollmentCheck = await pool.query(
      'SELECT * FROM enrollments WHERE id = $1 AND school_id = $2',
      [enrollmentId, schoolId]
    );

    if (enrollmentCheck.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Not Found',
        error: 'Enrollment record not found'
      });
    }

    const currentEnrollment = enrollmentCheck.rows[0];

    // Build update query
    let query = 'UPDATE enrollments SET ';
    const params = [];
    let paramIndex = 1;

    if (classId) {
      // Verify new class belongs to school
      const classCheck = await pool.query(
        'SELECT id FROM classes WHERE id = $1 AND school_id = $2',
        [classId, schoolId]
      );

      if (classCheck.rows.length === 0) {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized',
          error: 'Class not found in your school'
        });
      }

      query += `class_id = $${paramIndex}, `;
      params.push(classId);
      paramIndex++;
    }

    if (status) {
      query += `status = $${paramIndex}, `;
      params.push(status);
      paramIndex++;
    }

    query += `updated_at = CURRENT_TIMESTAMP WHERE id = $${paramIndex} AND school_id = $${paramIndex + 1} RETURNING *`;
    params.push(enrollmentId, schoolId);

    const result = await pool.query(query, params);

    res.status(200).json({
      success: true,
      message: 'Enrollment record updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Update Enrollment Error:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
      error: error.message
    });
  }
});




/**
 * @route   POST /api/students/email/template
 * @desc    Sends the bulk enrollment CSV template to the specified email
 * @access  Private
 */
router.post('/email/template', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, error: "Recipient email is required." });
    }

    const csvContent = "firstName,lastName,email,phone,studentNumber,gender\nJohn,Doe,john@example.com,1234567890,STU-001,Male";

    const mailOptions = {
      from: `"Sabino Edu" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "📋 Student Bulk Enrollment Template",
      html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 20px; border-radius: 10px;">
          <h2 style="color: #0F172A; text-align: center;">Bulk Enrollment Template</h2>
          <p>Hello,</p>
          <p>You requested a template for bulk student enrollment. Attached to this email is a CSV file that you can use to prepare your data.</p>
          <div style="background-color: #F8FAFC; padding: 15px; border-radius: 8px; border-left: 4px solid #FACC15; margin: 20px 0;">
            <p style="margin: 0; font-weight: bold; color: #334155;">Instructions:</p>
            <ul style="margin: 10px 0 0 0; color: #475569; font-size: 14px;">
              <li>Keep the column headers exactly as they are.</li>
              <li>Do not include <strong>classId</strong> in the CSV; class selection is handled in the portal.</li>
              <li>Save as .csv before uploading back to the portal.</li>
            </ul>
          </div>
          <p style="color: #64748B; font-size: 12px; text-align: center; margin-top: 30px;">
            &copy; ${new Date().getFullYear()} Sabino Edu
          </p>
        </div>
      `,
      attachments: [
        {
          filename: 'student_bulk_template.csv',
          content: csvContent
        }
      ]
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({
      success: true,
      message: "The template has been dispatched successfully."
    });

  } catch (error) {
    console.error("Email Dispatch Error:", error);
    res.status(500).json({ success: false, error: "Failed to dispatch email template." });
  }
});


/**
 * @route   POST /api/students/self-enroll
 * @desc    Allows a logged-in student to enroll themselves for a specific session
 * @access  Private (Student only)
 */
router.post('/self-enroll', authMiddleware.authenticateToken, authMiddleware.requireStudent, checkSubscription, async (req, res) => {
  const client = await pool.connect();
  try {
    // 1. Security Check: Ensure the user is a student
    if (req.user?.type !== 'student') {
      return res.status(403).json({ success: false, error: 'Only students can perform self-enrollment.' });
    }

    const studentId = req.user.studentId;
    const schoolId = req.user.schoolId;
    const { academicSession, classId } = req.body;

    if (!academicSession || !classId) {
      return res.status(400).json({ success: false, error: 'Academic session and Class ID are required.' });
    }

    await client.query('BEGIN');

    // 2. Lookup Academic Year/Session from global academic_years table
    const sessionLookup = await client.query(
      'SELECT id FROM academic_years WHERE session_name = $1 LIMIT 1',
      [academicSession]
    );

    if (sessionLookup.rows.length === 0) {
      throw new Error(`Academic session "${academicSession}" not found.`);
    }

    const sessionId = sessionLookup.rows[0].id;

    // 3. Verify Class exists (global template)
    const classCheck = await client.query(
      'SELECT id FROM global_class_templates WHERE id = $1',
      [classId]
    );

    if (classCheck.rows.length === 0) {
      throw new Error('The selected class is not valid.');
    }

    // 4. Check for Duplicate Enrollment
    // Prevent the student from enrolling in the same session twice
    const duplicateCheck = await client.query(
      'SELECT id FROM enrollments WHERE student_id = $1 AND session_id = $2',
      [studentId, sessionId]
    );

    if (duplicateCheck.rows.length > 0) {
      throw new Error(`You are already enrolled for the ${academicSession} session.`);
    }

    // 5. Perform Enrollment
    const enrollmentInsert = await client.query(
      `INSERT INTO enrollments (school_id, student_id, class_id, session_id, status)
       VALUES ($1, $2, $3, $4, 'active') RETURNING id`,
      [schoolId, studentId, classId, sessionId]
    );

    await client.query('COMMIT');

    res.status(201).json({
      success: true,
      message: `Successfully enrolled in session ${academicSession}`,
      enrollmentId: enrollmentInsert.rows[0].id
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error("Self-Enrollment Error:", error.message);
    res.status(500).json({ success: false, error: error.message });
  } finally {
    client.release();
  }
});

/**
 * @route   DELETE /api/students/:studentId/enrollment
 * @desc    Remove a student's enrollment from the school (unenroll without deleting the student record)
 * @access  Private (Authenticated schools only)
 * @param   studentId - the student to unenroll
 */
router.delete('/:studentId/enrollment', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, authMiddleware.requireOwner, async (req, res) => {
  const client = await pool.connect();

  try {
    // STRICT SECURITY: Extract schoolId ONLY from token, never from req.body or req.query
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;

    if (!schoolId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    if (!studentId || isNaN(studentId)) {
      return res.status(400).json({
        success: false,
        error: 'A valid studentId is required.'
      });
    }

    console.log(`📥 DELETE /students/${studentId}/enrollment - Requested by School: ${schoolId}`);

    await client.query('BEGIN');

    // Confirm the enrollment belongs to this school before deleting
    const enrollmentCheck = await client.query(
      `SELECT id FROM enrollments
       WHERE student_id = $1 AND school_id = $2`,
      [studentId, schoolId]
    );

    if (enrollmentCheck.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'Enrollment not found or does not belong to your school.'
      });
    }

    // Delete the enrollment record
    const result = await client.query(
      `DELETE FROM enrollments
       WHERE student_id = $1 AND school_id = $2
       RETURNING id`,
      [studentId, schoolId]
    );

    await client.query('COMMIT');

    console.log(`✅ Enrollment deleted for studentId: ${studentId} by schoolId: ${schoolId}`);

    res.status(200).json({
      success: true,
      message: `Student enrollment successfully removed.`,
      data: { deletedEnrollmentId: result.rows[0].id, studentId: parseInt(studentId) }
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Delete Enrollment Error:', error);
    res.status(500).json({ success: false, error: error.message });
  } finally {
    client.release();
  }
});

/**
 * @route   DELETE /api/students/:studentId
 * @desc    Permanently delete a student and all related records (cascades: enrollments, scores, reports)
 * @access  Private (Authenticated schools only)
 * @param   studentId - the student to delete
 */
router.delete('/:studentId', authMiddleware.authenticateToken, authMiddleware.requireSchool, checkSubscription, authMiddleware.requireOwner, async (req, res) => {
  const client = await pool.connect();

  try {
    // STRICT SECURITY: Extract schoolId ONLY from token, never from req.body or req.query
    const schoolId = req.user?.schoolId;
    const { studentId } = req.params;

    if (!schoolId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication context missing. Please login again.'
      });
    }

    if (!studentId || isNaN(studentId)) {
      return res.status(400).json({
        success: false,
        error: 'A valid studentId is required.'
      });
    }

    console.log(`📥 DELETE /students/${studentId} - Requested by School: ${schoolId}`);

    await client.query('BEGIN');

    // Confirm the student belongs to this school before doing anything
    const studentCheck = await client.query(
      `SELECT id, first_name, last_name FROM students
       WHERE id = $1 AND school_id = $2`,
      [studentId, schoolId]
    );

    if (studentCheck.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        error: 'Student not found or does not belong to your school.'
      });
    }

    const student = studentCheck.rows[0];
    const studentName = `${student.first_name} ${student.last_name}`.trim();

    // Delete dependent records first to avoid FK constraint violations
    // (skip any of these that don't apply to your schema)
    await client.query(`DELETE FROM scores       WHERE student_id = $1`, [studentId]);
    await client.query(`DELETE FROM reports      WHERE student_id = $1`, [studentId]);
    await client.query(`DELETE FROM enrollments  WHERE student_id = $1`, [studentId]);

    // Finally delete the student record itself
    await client.query(
      `DELETE FROM students WHERE id = $1 AND school_id = $2`,
      [studentId, schoolId]
    );

    await client.query('COMMIT');

    console.log(`✅ Student deleted: ${studentName} (id: ${studentId}) by schoolId: ${schoolId}`);

    res.status(200).json({
      success: true,
      message: `Student "${studentName}" and all related records have been permanently deleted.`,
      data: { deletedStudentId: parseInt(studentId) }
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Delete Student Error:', error);
    res.status(500).json({ success: false, error: error.message });
  } finally {
    client.release();
  }
});

// POST /api/students/push-token
// Call this from the app right after student login
router.post('/push-token', authMiddleware.authenticateToken, async (req, res) => {
  const { token, appVersion } = req.body;
  const studentId = req.user.studentId || req.user.id;

  if (!token || !token.startsWith('ExponentPushToken[')) {
    return res.status(400).json({ success: false, error: 'Invalid push token' });
  }

  try {
    // Ensure table exists (best effort)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS student_push_tokens (
        student_id INTEGER PRIMARY KEY REFERENCES students(id) ON DELETE CASCADE,
        expo_token VARCHAR(255) NOT NULL,
        app_version VARCHAR(50),
        version_notified_at TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(
      `INSERT INTO student_push_tokens (student_id, expo_token, app_version, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (student_id) DO UPDATE SET
         expo_token = EXCLUDED.expo_token,
         app_version = EXCLUDED.app_version,
         updated_at = NOW()`,
      [studentId, token, appVersion || null]
    );
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Student Push Token Error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;